import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import TimerSection from './components/TimerSection';
import TaskSection from './components/TasksSection';
import { TaskContext } from './context api/TaskContext';
import { useState } from 'react';

function App() {

  const [taskList,setTaskList]=useState([])
  return (
    <section>
      <TaskContext.Provider value={{taskList,setTaskList}}>
      <TimerSection/>
      <TaskSection/>
      </TaskContext.Provider>
     
    </section>
  );
}

export default App;
