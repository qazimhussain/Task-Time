import {Button} from '@mui/material'
import {Col, Container, Row} from 'react-bootstrap'
import FormatListBulletedRoundedIcon from '@mui/icons-material/FormatListBulletedRounded';
import { TaskContext } from '../context api/TaskContext';
import { useContext } from 'react';

function TaskSection() {
 const {taskList,setTaskList}= useContext(TaskContext)
console.log(taskList)
    return ( 
        <section className='mt-5'>
            <Container>
                <Row className='justify-content-center align-items-center'>
                    <Col lg='6' className=''>
                        <div className="d-flex  py-3 align-items-center border-bottom">
                        <FormatListBulletedRoundedIcon/>
                        <h3 className='ms-2 mb-0'>Tasks List </h3>
                        </div>
                       

                       {
                        taskList.length!==0?
<table className='table table-bordered'>
                            <thead>
                                <tr>
                                <th>S.No</th>
                                <th>Title</th>
                                <th>Time Tracked</th>
                                <th>Edit</th>
                                </tr>
                                </thead>

                                <tbody>

                                {
                                    taskList.map((elem,i)=>{
                                     return   <tr key={i}>
                                        <td>{i+1}</td>
                                        <td>{elem.title}</td>
                                        <td>{elem.hr<10?`0${elem.hr}`:elem.hr} : {elem.min<10?`0${elem.min}`:elem.min} : {elem.sec<10?`0${elem.sec}`:elem.sec}</td>
                                        <td><Button variant='contained' className='edit-btn'>Edit</Button></td>
                                    </tr>
                                    })
                                }

                                </tbody>


                               
                                
                            
                        </table>
                        :
                        <h5 className='my-4 text-center'>No task added yet</h5>
                       }


                        
                    </Col>
                </Row>
            </Container>

            
        </section>
     );
}

export default TaskSection;