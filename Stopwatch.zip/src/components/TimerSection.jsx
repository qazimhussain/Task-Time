import {Button} from '@mui/material'
import { useContext, useEffect, useRef, useState } from 'react';
import {Col, Container, Row,Modal,Form} from 'react-bootstrap'
import { TaskContext } from '../context api/TaskContext';

function TimerSection() {
    const [totalTime,setTotalTime]=useState(0)
  const [sec,setSec]=useState(0);
  const [min,setMin]=useState(0);
  const [hr,setHr]=useState(0);
  const [title,setTitle]=useState('')
  const [desc,setDesc]=useState('')

 const {taskList,setTaskList}= useContext(TaskContext)

  const startRef=useRef(null)
  const stopRef=useRef(null)

  const [runTime,setRunTime]=useState(false)

    const [show, setShow] = useState(false);


    useEffect(()=>{

      
        setTimeout(()=>{
          if(runTime)
      {
          setTotalTime(totalTime+1)
          setSec(totalTime%60)
          setMin(parseInt((totalTime%3600)/60))
          setHr(parseInt(totalTime/(3600)))
        console.log('hello',totalTime,runTime)

      }
      
        },1000)
      
      
       

        
    },[totalTime,runTime])

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);


  function onStart(e)
  {

    startRef.current.setAttribute('disabled','true')
    stopRef.current.removeAttribute('disabled')

    setRunTime(true)
     

    // console.log(startRef.current)
    
    
    

  }


  function onPause(e)
  {
    stopRef.current.setAttribute('disabled','true')
    startRef.current.removeAttribute('disabled')
    setRunTime(false)
    
  }

  function handleSubmit(e)
  {
    e.preventDefault()

    let taskObj={
      title:title,
      desc:desc,
      hr:hr,
      min:min,
      sec:sec,
    }

    setTaskList(current=>[taskObj,...current])

    setRunTime(false)
    setTimeout(()=>{
      setTotalTime(0)
      setHr(0)
      setSec(0)
      setMin(0)
      
    },1000)
   
   setShow(false)

    
    if(startRef.current.hasAttribute('disabled'))
    {
      startRef.current.removeAttribute('disabled')
    }
    else{
      stopRef.current.removeAttribute('disabled')
    }

   

 



 
   
   

  }





    return (
        <section>
            <Container>
                <Row>
                   <Col className='d-flex flex-column justify-content-center align-items-center'>
                   <div className="stopwatch">
             <span>{hr<10?`0${hr}`:hr}</span>
             <span>:</span>
             
             <span>{min<10?`0${min}`:min}</span>
             <span>:</span>
             <span>{sec<10?`0${sec}`:sec}</span>
            </div>
            <div className="stopwatchbtns mt-3">
              <Button ref={startRef} variant='contained' onClick={e=>{onStart(e)}}>Start</Button>
              <Button ref={stopRef} variant='contained' color='error' onClick={e=>{onPause(e)}}>Pause</Button>
              <Button variant='contained' color='success' onClick={handleShow}>Save</Button>
            </div>
                   </Col>
                </Row>
            </Container>


            <Modal show={show} onHide={handleClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>Add Task</Modal.Title>
        </Modal.Header>
        <Form onSubmit={(e=>{handleSubmit(e)})}>
        <Modal.Body>

        

        <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Title</Form.Label>
        <Form.Control type="text" placeholder="Enter Title" onChange={(e)=>{setTitle(e.target.value)}} required/>
      </Form.Group>


        <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Description</Form.Label>
        <Form.Control as={'textarea'} rows={'4'} placeholder='Enter Description' onChange={(e)=>{setDesc(e.target.value)}} required/>
      </Form.Group>

           

           
      
      </Modal.Body>
        <Modal.Footer>
          <Button variant="contained" type='submit'  className='me-2' color='success' >
            Save
          </Button>
          <Button variant="contained" type='button' color='error' onClick={handleClose}>
             Close
          </Button>
        </Modal.Footer>
        </Form>
      </Modal>
           
        </section>
      );
}

export default TimerSection;